function openSignIn()
{
    document.getElementById('myModal').style.display='block';
}
function openSignUp()
{
    document.getElementById('myModal1').style.display='block';
}
function onCloseModalClicked()
{
    document.getElementById('myModal').style.display='none';
    document.getElementById('myModal1').style.display='none';
}
function openSignUpButton()
{
    document.getElementById('myModal1').style.display='block';
}
